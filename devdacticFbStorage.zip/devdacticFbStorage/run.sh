npm install && echo 'Make sure to add your config in app.module.ts!'
