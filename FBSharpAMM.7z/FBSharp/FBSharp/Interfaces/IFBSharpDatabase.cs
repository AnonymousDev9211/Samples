﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBSharp.Interfaces
{
    interface IFBSharpDatabase
    {
        IDictionary<string, T> GetList<T>(string node);

        Task<IDictionary<string, T>> GetListAsync<T>(string node);

        Task<T> SaveRecord<T>(string node, T obj);

        Task<T> UpdateRecord<T>(string node, T obj);
    }
}
