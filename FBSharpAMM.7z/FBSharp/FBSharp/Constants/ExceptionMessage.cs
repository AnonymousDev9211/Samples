﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBSharp.Constants
{
    public static class ExceptionMessage
    {
        public  const string EmptyFBApiKey = "Firebase Api Key cannot be empty.";
    }
}
