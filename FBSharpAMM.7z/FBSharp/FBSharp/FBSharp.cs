﻿using FBSharp.Config;
using FBSharp.Constants;
using FBSharp.Interfaces;
using FBSharp.Model;
using Firebase.Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBSharp
{
    public class FBSharpAuth : IFBSharpAuth
    {
        #region Private Variables
        private FirebaseAuthProvider fbAuthProvider;
        private FirebaseAuthLink fbAuthLink;
        #endregion
        #region Constructor
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fbConfig"></param>
        public FBSharpAuth(FBSharpConfig fbConfig)
        {
            if (fbConfig == null || string.IsNullOrEmpty(fbConfig.FBApiKey))
            {
                throw new Exception(ExceptionMessage.EmptyFBApiKey);
            }
            fbAuthProvider = new FirebaseAuthProvider(new FirebaseConfig(fbConfig.FBApiKey));
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public async Task<FBUser> SignInWithEmail(string email, string password)
        {
            fbAuthLink = await fbAuthProvider.SignInWithEmailAndPasswordAsync(email, password);
            return GetFBUserDetails();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public async Task<FBUser> SignInAnonymously()
        {
            fbAuthLink = await fbAuthProvider.SignInAnonymouslyAsync();
            return GetFBUserDetails();
        }

        public async Task<FBUser> CreateUser(string email, string password, string fullName, bool sendVerificationEmail)
        {
            fbAuthLink = await fbAuthProvider.CreateUserWithEmailAndPasswordAsync(email, password, fullName, sendVerificationEmail);
            return GetFBUserDetails();
        }
        #endregion

        #region Private Methods
        public FBUser GetFBUserDetails()
        {
            return new FBUser() {
                 DisplayName = fbAuthLink.User.DisplayName
                ,Email = fbAuthLink.User.Email
                ,FirstName = fbAuthLink.User.FirstName
                ,LastName = fbAuthLink.User.LastName
                ,PhoneNumber = fbAuthLink.User.PhoneNumber
                ,PhotoUrl = fbAuthLink.User.PhotoUrl
                ,UserId = fbAuthLink.User.LocalId
                ,IsEmailVerified = fbAuthLink.User.IsEmailVerified
            };
        }
        #endregion
    }
}
