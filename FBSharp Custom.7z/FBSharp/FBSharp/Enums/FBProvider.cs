﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBSharp.Enums
{
    public class FBProvider
    {
        enum Provider
        {
            Email = 1,
            Phone = 2
        }
    }
}
