﻿using FBSharp.Model;
using Firebase.Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBSharp.Interfaces
{
    interface IFBSharpAuth
    {
        Task<FBUser> SignInWithEmail(string email, string password);

        Task<FBUser> SignInAnonymously();

        Task<FBUser> CreateUser(string email, string password, string fullName, bool sendVerificationEmail);


    }
}
