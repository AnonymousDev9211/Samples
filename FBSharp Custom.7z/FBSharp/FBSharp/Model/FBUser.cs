﻿using FBSharp.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBSharp.Model
{
    public class FBUser
    {
        [DefaultValue("")]
        [JsonProperty("displayName", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string DisplayName { get; set; }
        [DefaultValue("")]
        [JsonProperty("email", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Email { get; set; }
      
        [DefaultValue("")]
        [JsonProperty("firstName", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string FirstName { get; set; }
        [DefaultValue(false)]
        [JsonProperty("emailVerified", DefaultValueHandling = DefaultValueHandling.Populate)]
        public bool IsEmailVerified { get; set; }
        [DefaultValue("")]
        [JsonProperty("lastName", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string LastName { get; set; }
        [DefaultValue("")]
        [JsonProperty("localId", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string UserId { get; set; }
        [DefaultValue("")]
        [JsonProperty("phoneNumber", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string PhoneNumber { get; set; }
        [DefaultValue("")]
        [JsonProperty("photoUrl", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string PhotoUrl { get; set; }
    }
}
