﻿using FBSharp.Config;
using FBSharp.Interfaces;
using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBSharp
{
    public class FBSharpDatabase : IFBSharpDatabase
    {
        private IFirebaseConfig config;
        private IFirebaseClient client;

        public FBSharpDatabase(FBSharpConfig fbConfig)
        {
            config = new FirebaseConfig
            {
                AuthSecret = fbConfig.FBDataBaseSecret,
                BasePath = fbConfig.FBUrl
            };
            client = new FirebaseClient(config);
        }
        public IDictionary<string, T> GetList<T>(string node)
        {
            var fbResponse = client.Get(node);
            return fbResponse.ResultAs<IDictionary<string, T>>();
        }

        public async Task<IDictionary<string, T>> GetListAsync<T>(string node)
        {
            var fbResponse = await client.GetAsync(node);
            return fbResponse.ResultAs<IDictionary<string, T>>();
        }
    }
}
