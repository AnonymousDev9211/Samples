﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBSharp.Config
{
    public class FBSharpConfig
    {
        public string FBApiKey { get; set; }
        public string FBUrl { get; set; }
        public string FBDataBaseSecret { get; set; }
    }
}
