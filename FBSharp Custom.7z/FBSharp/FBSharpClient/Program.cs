﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBSharpClient
{
    public class Message
    {
        public string name { get; set; }
        public string text { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Run().Wait();
        }

        private static async Task Run()
        {
            var firebaseApiKey = "AIzaSyDgA6KUZDLfL4SLBa1PQduBNU2XyQPpumg"; // your app secret
            var user = "anonymousdev921111@gmail.com";
            var pw = "abcd@1234";

            //var fbSharp = new FBSharp.FBSharpAuth(new FBSharp.Config.FBSharpConfig() { FBApiKey = firebaseApiKey });
            //var fbUser = await fbSharp.CreateUser(user, pw, "Sajid Nisar", true);
            //Console.WriteLine(fbUser.Email);

            string BASE_PATH = "https://chat-d0428.firebaseio.com";// "https://firesharp.firebaseio.com/";
            string FIREBASE_SECRET = "yKoKKEzSmu8Rz3T5Is4rHKrBtvv0FtvtI1E7uIGQ";
            FBSharp.FBSharpDatabase fbDB = new FBSharp.FBSharpDatabase(new FBSharp.Config.FBSharpConfig() { FBUrl = BASE_PATH, FBDataBaseSecret = FIREBASE_SECRET });
            var lst = await fbDB.GetListAsync<Message>("Message");
            foreach (var item in lst)
            {
                var m = item.Value.name;
                Console.WriteLine(m);
            }
        }
    }
}
