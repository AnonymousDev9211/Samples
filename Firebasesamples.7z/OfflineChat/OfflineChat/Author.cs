﻿namespace Firebase.Database.OfflineChat
{
    public class Author
    {
        public string Name { get; set; }
    }
}
